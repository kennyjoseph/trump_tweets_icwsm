(function(){
  window['optimizely'] = window['optimizely'] || [];
  window['optimizely'].push(['activateGeoDelayedExperiments', {
    'location':{
      'city': "BUFFALO",
      'continent': "NA",
      'country': "US",
      'region': "NY"
    },
    'ip':"24.30.250.76"
  }]);
})
//
()

;