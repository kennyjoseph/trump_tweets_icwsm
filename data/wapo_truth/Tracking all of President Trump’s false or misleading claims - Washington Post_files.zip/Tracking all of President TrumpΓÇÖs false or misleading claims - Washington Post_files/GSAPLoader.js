function loadServingSysScript(filename) {
    document.write("<script src='" + (document.location.protocol === "https:" ? "https://secure-" : "http://") + "ds.serving-sys.com/BurstingcachedScripts/libraries/greensock/1_19_0/" + filename + "'><\/script>");
}

//Load secure or insecure version of GSAP modules
loadServingSysScript("TweenLite.min.js");
//loadServingSysScript("TweenMax.min.js");
loadServingSysScript("TimelineLite.min.js");
loadServingSysScript("easing/easepack.min.js");
loadServingSysScript("plugins/cssplugin.min.js");
