// animation_300x250.js
// custom animation for polite Sizmek banners

var bgTL, mainTL, cloudInTL, cloudOutTL, cloudBounceTL, cloudStopTL, arrowTL;
var canSvg;
var animLoaded=true;

function is_anim_loaded() {
	animLoaded=true;
	return true;
}

function firstrun_setup() { 
	TweenLite.defaultOverwrite = 3;
	TweenLite.set(".text", {force3D:true});
	TweenLite.set("#bg", {force3D:true});
	TweenLite.set("#ctaArrow", {force3D:true});
	TweenLite.set("#bg", {transformOrigin:"50% 50%"});
	TweenLite.set("#replayButton", {svgOrigin:"10px 10px", transformOrigin:"10px 10px"});
	//
	canSvg = !!(document.createElementNS && document.createElementNS('http://www.w3.org/2000/svg','svg').createSVGRect);
	if (canSvg===false) {
		TweenLite.set("#cloudGroup", {display:"none"});
		TweenLite.set("#backupDiv", {display:"block"});
	} else {
		TweenLite.set(".expG",{transformOrigin:"150px 60px"});
		TweenLite.set("#exp1Pos",{x:24,y:33,rotation:-60,transformOrigin:"70px 60px"});
		TweenLite.set("#exp2Pos",{x:10,y:9,rotation:-30,transformOrigin:"108px 60px"});
		TweenLite.set("#exp3Pos",{x:0,y:0,rotation:0,transformOrigin:"150px 60px"});
		TweenLite.set("#exp4Pos",{x:-10.5,y:8.5,rotation:30,transformOrigin:"193px 60px"});
		TweenLite.set("#exp5Pos",{x:-21,y:32,rotation:60,transformOrigin:"226px 60px"});
		TweenLite.set("#cloudSVG",{scale:.9, x:10,y:35});
		TweenLite.set("#cloudExp",{display:"block"});
		TweenLite.set(".ibmLogoB",{opacity:0});
	}
	build_timelines();
}

function ad_begin() {
	clearTimeout(loadingTimer);
	ad.style.visibility="visible";
	ad_reset();
	bgTL.play(0);
	mainTL.play(0);
}

function ad_reset() {
	atEndframe=false;
	timesUp=false;
	skipped=false;
	TweenLite.set(".frame", {display:"block"});
	//reset_cloud();
	TweenLite.set("#cloudExp",{display:"none"});
	TweenLite.set(".expG", {y:12,scaleY:0});
}

function shuffleArray(array) {
    for (var i = array.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
    return array;
}


function build_timelines() {
					
	//// CLOUD ANIMATION
	
	cloudInTL = new TimelineLite({ paused:true });	
	cloudInTL	
		.add("up")			
		.to("#exp3Anim", 0.2, {scaleY:1, ease:Back.easeOut.config(1.0)}, "up+=0.0")
		.to("#exp2Anim", 0.2, {scaleY:1, ease:Back.easeOut.config(1.0)}, "up+=0.05")
		.to("#exp4Anim", 0.2, {scaleY:1, ease:Back.easeOut.config(1.0)}, "up+=0.05")
		.to("#exp1Anim", 0.2, {scaleY:1, ease:Back.easeOut.config(1.0)}, "up+=0.1")
		.to("#exp5Anim", 0.2, {scaleY:1, ease:Back.easeOut.config(1.0)}, "up+=0.1")
		.to("#exp3Anim", 0.2, {y:0, ease:Back.easeOut.config(1.0)}, "up+=0.0")
		.to("#exp2Anim", 0.2, {y:0, ease:Back.easeOut.config(1.0)}, "up+=0.05")
		.to("#exp4Anim", 0.2, {y:0, ease:Back.easeOut.config(1.0)}, "up+=0.05")
		.to("#exp1Anim", 0.2, {y:0, ease:Back.easeOut.config(1.0)}, "up+=0.1")
		.to("#exp5Anim", 0.2, {y:0, ease:Back.easeOut.config(1.0)}, "up+=0.1")
	.add("end");
	
	cloudOutTL = new TimelineLite({ paused:true });	
	cloudOutTL	
		.add("down")
		.to("#exp3Anim", 0.2, {scaleY:0, ease:Back.easeIn.config(1.0)}, "down+=0.0")
		.to("#exp2Anim", 0.2, {scaleY:0, ease:Back.easeIn.config(1.0)}, "down+=0.05")
		.to("#exp4Anim", 0.2, {scaleY:0, ease:Back.easeIn.config(1.0)}, "down+=0.05")
		.to("#exp1Anim", 0.2, {scaleY:0, ease:Back.easeIn.config(1.0)}, "down+=0.1")
		.to("#exp5Anim", 0.2, {scaleY:0, ease:Back.easeIn.config(1.0)}, "down+=0.1")
		.to("#exp3Anim", 0.2, {y:10, ease:Back.easeIn.config(1.0)}, "down+=0.0")
		.to("#exp2Anim", 0.2, {y:10, ease:Back.easeIn.config(1.0)}, "down+=0.05")
		.to("#exp4Anim", 0.2, {y:10, ease:Back.easeIn.config(1.0)}, "down+=0.05")
		.to("#exp1Anim", 0.2, {y:10, ease:Back.easeIn.config(1.0)}, "down+=0.1")
		.to("#exp5Anim", 0.2, {y:10, ease:Back.easeIn.config(1.0)}, "down+=0.1")
	.add("end");

	cloudBounceTL = new TimelineLite({ paused:true });	
	cloudBounceTL	
		.add("bounce")	
		// up
		.to("#exp3Anim", 0.2, {scaleY:1.0,y:-10, ease:Power2.easeIn}, "bounce+=0.0")
		.to("#exp2Anim", 0.2, {scaleY:1.0,y:-10, ease:Power2.easeIn}, "bounce+=0.05")
		.to("#exp4Anim", 0.2, {scaleY:1.0,y:-10, ease:Power2.easeIn}, "bounce+=0.05")
		.to("#exp1Anim", 0.2, {scaleY:1.0,y:-10, ease:Power2.easeIn}, "bounce+=0.1")
		.to("#exp5Anim", 0.2, {scaleY:1.0,y:-10, ease:Power2.easeIn}, "bounce+=0.1")
		// dn
		.to("#exp3Anim", 0.2, {scaleY:1,y:0, ease:Power3.easeOut}, "bounce+=0.26")
		.to("#exp2Anim", 0.2, {scaleY:1,y:0, ease:Power3.easeOut}, "bounce+=0.36")
		.to("#exp4Anim", 0.2, {scaleY:1,y:0, ease:Power3.easeOut}, "bounce+=0.36")
		.to("#exp1Anim", 0.2, {scaleY:1,y:0, ease:Power3.easeOut}, "bounce+=0.46")
		.to("#exp5Anim", 0.2, {scaleY:1,y:0, ease:Power3.easeOut}, "bounce+=0.46")
	.add("end", "+=0");
	
	cloudStopTL = new TimelineLite({ paused:true });	
	cloudStopTL	
		.add("stop")	
		.set(".expG", {scaleY:1,y:0})
	.add("end", "+=0");
	
	
	bgTL = new TimelineLite({ paused:true });	
	bgTL
		.fromTo("#bg", 1.6, {top:0, opacity:1,scaleX:1, scaleY:1},{top:0, opacity:1, scaleX:1.2, scaleY:1.2, ease:"Power2.easeOut"}, "start")
		//.fromTo("#bgB", 3, {opacity:0,},{opacity:1, ease:"Power3.easeInOut"}, 0 ) 
		.add("end");
	
	//// MAIN ANIMATION

	var cloudTime = "+=0.5";
	var textInTime = "+=0.1";
	var textOutTime = "+=0.2";
			
	mainTL = new TimelineLite({ paused:true });	
	mainTL	    
		//fr1in
		.add("fr1")
		.fromTo("#bg", 0, {opacity:0},{opacity:1, ease:"Power3.easeOut"}, "fr1") 
		//fr2in	
		.add("fr2", "+=0.25") 
		.staggerFromTo("#text2 .text", 0.45, {opacity:0,y:50},{opacity:1,y:0, ease:"Power2.easeOut"}, 0, ("fr2"+textInTime) )
		.add("fr2", "+=0.65") 
		.set("#cloudExp", {display:"block"}, "fr2"+textInTime)
		.call(play_cloud_in, [], this, ("fr2"+cloudTime) )
		//fr2out	
		.add("fr2out", "+=1.5")		
		.staggerTo("#text2 .text", 0.35, {opacity:0, y:-15, ease:"Power2.easeIn"}, 0, ("fr2out"+textOutTime) )
		//fr3in	
		.add("fr3", "+=0.25") 
		.staggerFromTo("#text3 .text", 0.45, {opacity:0,y:50},{opacity:1,y:0, ease:"Power2.easeOut"}, 0, ("fr3"+textInTime) )
		.add("fr3", "+=0.25") 
		.staggerFromTo(".ibmLogoB", 0.45, {opacity:0},{opacity:1, ease:"Power2.easeOut"}, 0, ("fr3"+textInTime) )
		//cta
		.staggerFromTo("#cta .text", 0.45, {opacity:0, y:25},{opacity:1, y:0, ease:"Power2.easeOut"}, 0, "+=0.25" )
		// ARROW
		.fromTo("#ctaArrow", 0.1, {opacity:0,x:-5},{opacity:1,x:10}, "-=0.2" )
		.to("#ctaArrow", 0.5, {x:0, ease:"Power2.easeOut"}, "+=0" )
		// replay
		.fromTo("#replayButton", 0.75, {display:"none",opacity:0,rotation:-180},{display:"block",opacity:1,rotation:0, ease:"Power3.easeOut"}, "+=0") 

		.add("efbounce", "+=0.5") 
		//.call(play_cloud_bounce, [], this, "efbounce+=0" )
		.call(play_arrow, [], this, "efbounce+=0.75" )
		//.call(play_cloud_bounce, [], this, "efbounce+=1.75" )
	
		.add("ef")
		//.call(function(){console.log(mainTL.duration());})
	.call(at_endframe);

		
	//// endframe arrow animation
  arrowTL = new TimelineLite({paused:true});
  arrowTL
	  .to("#ctaArrow", 0.2, {x:7, ease:"Power2.easeIn"} )
	  .to("#ctaArrow", 0.2, {x:0, ease:"Power2.easeOut"} )
	  .set({}, {}, "+=0.07")
	  .to("#ctaArrow", 0.2, {x:7, ease:"Power2.easeIn"} )
	  .to("#ctaArrow", 0.2, {x:0, ease:"Power2.easeOut"} );
}

//// PLAY TIMELINES

function play_cloud_in() {
	if (canSvg) { cloudInTL.invalidate().play(0); }
	else { TweenLite.fromTo("#pngExpWhite", 0.3, {opacity:0,scale:0.75},{opacity:1,scale:1,ease:Back.easeOut.config(5.0)}); }
}

function play_cloud_out() {
	if (canSvg) { cloudOutTL.invalidate().play(0); }
	else { TweenLite.to("#pngExpWhite", 0.3, {opacity:0,scale:0.75,ease:Back.easeIn.config(5.0)}); }
}

function play_cloud_bounce() {
	if (canSvg) { cloudBounceTL.invalidate().play(0); }
	else { 
		TweenLite.to("#pngExpWhite", 0.3, {scale:1.15,ease:Back.easeIn.config(2.0)}); 
		TweenLite.to("#pngExpWhite", 0.3, {delay:0.35,scale:1,ease:Back.easeOut.config(5.0)}); 
	}
}

function reset_cloud() {
	if (canSvg) { 		
		//mainTL.pause().kill();
		cloudInTL.pause().kill();
		cloudOutTL.pause().kill();
		cloudBounceTL.pause().kill();			
		cloudStopTL.invalidate().play(0);
	}
}

function play_arrow() {
    arrowTL.play(0);
}

//// INTERACTIVE

function custom_clickthru_over() {
	play_arrow();
	console.log("arrow");
	//play_cloud_bounce();	
}

//// ENDFRAME

function at_endframe() {
	atEndframe=true;
}

function jump_to_endframe() {
	skipped=true;
	reset_cloud();
	bgTL.play("end");
	try { mainTL.pause("ef"); } catch(e) { } // mainTL may not have been created yet
}
